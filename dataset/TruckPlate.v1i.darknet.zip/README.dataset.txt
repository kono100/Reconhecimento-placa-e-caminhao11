# TruckPlate > 2024-01-12 12:48pm
https://universe.roboflow.com/faculdade-reges-jdihd/truckplate

Provided by a Roboflow user
License: CC BY 4.0

